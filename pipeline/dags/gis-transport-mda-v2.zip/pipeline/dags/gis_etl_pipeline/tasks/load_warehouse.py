from datetime import datetime
# from airflow.hooks.base import BaseHook
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, avg, sum as _sum, lit

DATE_STR = datetime.today().strftime('%Y-%m-%d')
INPUT    = f's3a://transport-bucket/staging/trips_enriched_{DATE_STR}.parquet'

# PG_CONN  = BaseHook.get_connection('transport-warehouse-db-conn')
# PG_URL   = f'jdbc:postgresql://{PG_CONN.host}:{PG_CONN.port}/{PG_CONN.schema}'
# PG_PROPS = {'user': PG_CONN.login, 'password': PG_CONN.password, 'driver': 'org.postgresql.Driver'}

PG_URL = "jdbc:postgresql://sources:5432/transport_db"
PG_PROPS = {
    "user": "postgres",
    "password": "postgres",
    "driver": "org.postgresql.Driver"
}

spark = SparkSession.builder.appName('GIS_LoadWarehouse').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

df = spark.read.parquet(INPUT)

df = df.withColumnRenamed("processed_at", "created_at")

df.write.mode('append').jdbc(url=PG_URL, table='public.trips_enriched',
                              properties={**PG_PROPS, 'batchsize': '1000'})

(df.groupBy('origin_zone')
   .agg(count('trip_id').alias('trip_count'),
        avg('actual_fare').alias('avg_fare'),
        avg('distance_km').alias('avg_distance_km'),
        avg('surge_multiplier').alias('avg_surge'),
        _sum((col('weather').isin('rain', 'heavy_rain')).cast('int')).alias('rain_trip_count'))
   .withColumnRenamed('origin_zone', 'zone')
   .withColumn('stat_date', lit(DATE_STR))
   .write.mode('append').jdbc(url=PG_URL, table='public.zone_daily_stats', properties=PG_PROPS))

print('warehouse updated')
spark.stop()
