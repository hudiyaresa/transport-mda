from datetime import datetime
# from airflow.hooks.base import BaseHook
from pyspark.sql import SparkSession

# PG_CONN  = BaseHook.get_connection('transport-source-db-conn')
# PG_URL   = f'jdbc:postgresql://{PG_CONN.host}:{PG_CONN.port}/{PG_CONN.schema}'
# PG_PROPS = {'user': PG_CONN.login, 'password': PG_CONN.password, 'driver': 'org.postgresql.Driver'}
PG_URL = "jdbc:postgresql://sources:5432/transport_db"
PG_PROPS = {
    "user": "postgres",
    "password": "postgres",
    "driver": "org.postgresql.Driver"
}
DATE_STR = datetime.today().strftime('%Y-%m-%d')
OUTPUT   = f's3a://transport-bucket/staging/raw_trips_{DATE_STR}.parquet'

spark = SparkSession.builder.appName('GIS_ExtractData').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

df = spark.read.jdbc(
    url=PG_URL,
    table='(SELECT * FROM public.raw_trips WHERE DATE(created_at) = CURRENT_DATE) AS t',
    properties=PG_PROPS,
)
print(f'rows: {df.count():,}')
df.write.mode('overwrite').parquet(OUTPUT)
spark.stop()
