from pyspark.ml.regression import GBTRegressor
from pyspark.sql import SparkSession

TRAIN_PATH = 's3a://transport-bucket/ml/preprocessed/train.parquet'
MODEL_PATH = 's3a://transport-bucket/ml/model/fare_model_new'

spark = SparkSession.builder.appName('FarePred_Train').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

train_df = spark.read.parquet(TRAIN_PATH)
model = GBTRegressor(featuresCol='features', labelCol='label',
                     maxIter=100, maxDepth=5, stepSize=0.1,
                     subsamplingRate=0.8, seed=42).fit(train_df)
model.write().overwrite().save(MODEL_PATH)
print(f'model saved to {MODEL_PATH}')
spark.stop()
