# from airflow.hooks.base import BaseHook
from pyspark.sql import SparkSession

# PG_CONN  = BaseHook.get_connection('transport-warehouse-db-conn')
# PG_URL   = f'jdbc:postgresql://{PG_CONN.host}:{PG_CONN.port}/{PG_CONN.schema}'
# PG_PROPS = {'user': PG_CONN.login, 'password': PG_CONN.password, 'driver': 'org.postgresql.Driver'}

PG_URL = "jdbc:postgresql://sources:5432/transport_db"
PG_PROPS = {
    "user": "postgres",
    "password": "postgres",
    "driver": "org.postgresql.Driver"
}

OUTPUT   = 's3a://transport-bucket/ml/raw_training_data.parquet'

spark = SparkSession.builder.appName('FarePred_ExtractData').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

df = spark.read.jdbc(url=PG_URL, properties=PG_PROPS, table="""(
    SELECT trip_id, origin_lat, origin_lng, dest_lat, dest_lng,
           distance_km, vehicle_type, surge_multiplier, weather,
           hour_of_day, day_of_week, origin_zone, dest_zone, actual_fare
    FROM public.trips_enriched
    WHERE processed_at >= NOW() - INTERVAL '90 days'
      AND actual_fare IS NOT NULL AND actual_fare > 0
) AS t""")

print(f'training samples: {df.count():,}')
df.write.mode('overwrite').parquet(OUTPUT)
spark.stop()
