from datetime import datetime
# from airflow.hooks.base import BaseHook
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, abs as spark_abs, lit

# PG_CONN  = BaseHook.get_connection('transport-warehouse-db-conn')
# PG_URL   = f'jdbc:postgresql://{PG_CONN.host}:{PG_CONN.port}/{PG_CONN.schema}'
# PG_PROPS = {'user': PG_CONN.login, 'password': PG_CONN.password, 'driver': 'org.postgresql.Driver'}

PG_URL = "jdbc:postgresql://sources:5432/transport_db"
PG_PROPS = {
    "user": "postgres",
    "password": "postgres",
    "driver": "org.postgresql.Driver"
}

spark = SparkSession.builder.appName('AddTrainingDataset').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

df = spark.read.jdbc(url=PG_URL, properties=PG_PROPS, table="""(
    SELECT * FROM public.trip_predictions
    WHERE actual_fare IS NOT NULL AND predicted_fare > 0 AND actual_fare > 0
) AS preds""")

df_valid = df.filter(
    spark_abs(col('predicted_fare') - col('actual_fare')) / col('actual_fare') <= 0.20
)
n = df_valid.count()
print(f'valid samples: {n:,}')
if n == 0:
    spark.stop()
    exit(0)

(df_valid.drop('predicted_fare')
         .withColumn('processed_at', lit(datetime.today().strftime('%Y-%m-%d %H:%M:%S')))
         .write.mode('append')
         .jdbc(url=PG_URL, table='public.trips_enriched', properties=PG_PROPS))
spark.stop()
