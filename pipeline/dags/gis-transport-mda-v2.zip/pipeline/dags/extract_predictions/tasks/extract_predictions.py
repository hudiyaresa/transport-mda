# from airflow.hooks.base import BaseHook
from pyspark.ml import PipelineModel
from pyspark.ml.regression import GBTRegressionModel
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, exp

PIPE_PATH  = 's3a://transport-bucket/ml/pipeline_model'
MODEL_PATH = 's3a://transport-bucket/ml/model/fare_model_new'

# PG_CONN  = BaseHook.get_connection('transport-warehouse-db-conn')
# PG_URL   = f'jdbc:postgresql://{PG_CONN.host}:{PG_CONN.port}/{PG_CONN.schema}'
# PG_PROPS = {'user': PG_CONN.login, 'password': PG_CONN.password, 'driver': 'org.postgresql.Driver'}

PG_URL = "jdbc:postgresql://sources:5432/transport_db"
PG_PROPS = {
    "user": "postgres",
    "password": "postgres",
    "driver": "org.postgresql.Driver"
}

spark = SparkSession.builder.appName('FarePred_BatchScore').getOrCreate()
spark.sparkContext.setLogLevel('WARN')

df = spark.read.jdbc(url=PG_URL, properties=PG_PROPS, table="""(
    SELECT te.* FROM public.trips_enriched te
    LEFT JOIN public.trip_predictions tp USING (trip_id)
    WHERE tp.trip_id IS NULL LIMIT 50000
) AS unscored""")

n = df.count()
print(f'unscored trips: {n:,}')
if n == 0:
    spark.stop()
    exit(0)

result = (GBTRegressionModel.load(MODEL_PATH)
          .transform(PipelineModel.load(PIPE_PATH).transform(df))
          .withColumn('predicted_fare', exp(col('prediction')) - 1)
          .select('trip_id', 'origin_lat', 'origin_lng', 'dest_lat', 'dest_lng',
                  'distance_km', 'vehicle_type', 'surge_multiplier', 'weather',
                  'hour_of_day', 'day_of_week', 'origin_zone', 'predicted_fare', 'actual_fare'))

result.write.mode('append').jdbc(url=PG_URL, table='public.trip_predictions', properties=PG_PROPS)
print(f'predictions written: {result.count():,}')
spark.stop()
